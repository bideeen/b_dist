from .Guassiandistribution import Guassian
from .Generaldistribution import Distribution
from .Binomialdistribution import Binomial